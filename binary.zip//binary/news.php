<div class="news blue">
<span>Latest News</span><span class="text1" ><marquee>Welcome to Income 899 in Binary Plan. Please change ur password as soon as possible.</marquee></span>
</div>